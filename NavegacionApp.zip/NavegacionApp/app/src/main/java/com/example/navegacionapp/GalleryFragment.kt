package com.example.navegacionapp

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class GalleryFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_gallery, container, false)
        val txtHistorial = view.findViewById<TextView>(R.id.txtHistorial)

        val dbHelper = DatabaseHelper(requireContext())
        val prefs = requireActivity().getSharedPreferences("SesionUsuario", Context.MODE_PRIVATE)
        val usuarioLogueado = prefs.getString("email", "Anónimo") ?: "Anónimo"

        val db = dbHelper.readableDatabase

        val query = """
            SELECT e.${DatabaseHelper.KEY_EV_TITULO}, e.${DatabaseHelper.KEY_EV_FECHA} 
            FROM ${DatabaseHelper.TABLA_HISTORIAL} h
            INNER JOIN ${DatabaseHelper.TABLA_EVENTOS} e ON h.${DatabaseHelper.KEY_HIST_EVENTO_ID} = e.${DatabaseHelper.KEY_EV_ID}
            WHERE h.${DatabaseHelper.KEY_HIST_USER_EMAIL} = ?
        """.trimIndent()

        val cursor = db.rawQuery(query, arrayOf(usuarioLogueado))

        if (cursor.moveToFirst()) {
            var historialTexto = "Eventos a los que te has inscrito:\n\n"
            var contador = 1
            do {
                val titulo = cursor.getString(0)
                val fecha = cursor.getString(1)
                historialTexto += "$contador. ✅ $titulo (Fecha: $fecha)\n"
                contador++
            } while (cursor.moveToNext())
            txtHistorial.text = historialTexto
        } else {
            txtHistorial.text = "Hola $usuarioLogueado,\nNo hay asistencias marcadas aún."
        }
        cursor.close()

        return view
    }
}