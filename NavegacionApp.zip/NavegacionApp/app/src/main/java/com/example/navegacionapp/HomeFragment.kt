package com.example.navegacionapp

import android.content.ContentValues
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

class HomeFragment : Fragment() {

    private var eventoActualId: Int = 1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        val dbHelper = DatabaseHelper(requireContext())
        val prefs = requireActivity().getSharedPreferences("SesionUsuario", Context.MODE_PRIVATE)
        val usuarioLogueado = prefs.getString("email", "Anónimo") ?: "Anónimo"

        val edtTitulo = view.findViewById<EditText>(R.id.edtTituloEv)
        val edtUbicacion = view.findViewById<EditText>(R.id.edtUbicacionEv)
        val btnGuardarEv = view.findViewById<Button>(R.id.btnGuardarEv)
        val txtDetalle = view.findViewById<TextView>(R.id.txtDetalleEvento)
        val btnAsistir = view.findViewById<Button>(R.id.btnAsistir)

        val edtComentario = view.findViewById<EditText>(R.id.edtComentario)
        val edtEstrellas = view.findViewById<EditText>(R.id.edtEstrellas)
        val btnEnviarComentario = view.findViewById<Button>(R.id.btnEnviarComentario)
        val txtListaComentarios = view.findViewById<TextView>(R.id.txtListaComentarios)

        fun cargarUltimoEvento() {
            val db = dbHelper.readableDatabase
            val cursor = db.rawQuery("SELECT * FROM ${DatabaseHelper.TABLA_EVENTOS} ORDER BY ${DatabaseHelper.KEY_EV_ID} DESC LIMIT 1", null)
            if (cursor.moveToFirst()) {
                eventoActualId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_EV_ID))
                val titulo = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_EV_TITULO))
                val ubicacion = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_EV_UBICACION))
                val fecha = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_EV_FECHA))

                txtDetalle.text = "📌 Título: $titulo\n📍 Lugar: $ubicacion\n📅 Fecha: $fecha"
            }
            cursor.close()

            val cursorCom = db.rawQuery("SELECT * FROM ${DatabaseHelper.TABLA_COMENTARIOS} WHERE ${DatabaseHelper.KEY_COM_EVENTO_ID} = ?", arrayOf(eventoActualId.toString()))
            var cadenaComentarios = "Comentarios de la Comunidad:\n"
            if (cursorCom.moveToFirst()) {
                do {
                    val user = cursorCom.getString(cursorCom.getColumnIndexOrThrow(DatabaseHelper.KEY_COM_USUARIO))
                    val text = cursorCom.getString(cursorCom.getColumnIndexOrThrow(DatabaseHelper.KEY_COM_TEXTO))
                    val stars = cursorCom.getInt(cursorCom.getColumnIndexOrThrow(DatabaseHelper.KEY_COM_ESTRELLAS))
                    cadenaComentarios += "👤 $user (${stars}⭐): $text\n"
                } while (cursorCom.moveToNext())
                txtListaComentarios.text = cadenaComentarios
            } else {
                txtListaComentarios.text = "No hay valoraciones en este momento."
            }
            cursorCom.close()
        }

        btnGuardarEv.setOnClickListener {
            val t = edtTitulo.text.toString().trim()
            val u = edtUbicacion.text.toString().trim()
            if(t.isNotEmpty() && u.isNotEmpty()) {
                val db = dbHelper.writableDatabase
                val v = ContentValues().apply {
                    put(DatabaseHelper.KEY_EV_TITULO, t)
                    put(DatabaseHelper.KEY_EV_UBICACION, u)
                    put(DatabaseHelper.KEY_EV_FECHA, "2026-06-01")
                    put(DatabaseHelper.KEY_EV_HORA, "14:00")
                }
                db.insert(DatabaseHelper.TABLA_EVENTOS, null, v)
                Toast.makeText(context, "¡Evento publicado!", Toast.LENGTH_SHORT).show()
                edtTitulo.text.clear()
                edtUbicacion.text.clear()
                cargarUltimoEvento()
            }
        }

        btnAsistir.setOnClickListener {
            val db = dbHelper.writableDatabase
            val v = ContentValues().apply {
                put(DatabaseHelper.KEY_HIST_USER_EMAIL, usuarioLogueado)
                put(DatabaseHelper.KEY_HIST_EVENTO_ID, eventoActualId)
            }
            db.insert(DatabaseHelper.TABLA_HISTORIAL, null, v)
            Toast.makeText(context, "Asistencia guardada en el historial", Toast.LENGTH_SHORT).show()
        }

        btnEnviarComentario.setOnClickListener {
            val comText = edtComentario.text.toString().trim()
            val starVal = edtEstrellas.text.toString().trim()
            if (comText.isNotEmpty() && starVal.isNotEmpty()) {
                val db = dbHelper.writableDatabase
                val v = ContentValues().apply {
                    put(DatabaseHelper.KEY_COM_EVENTO_ID, eventoActualId)
                    put(DatabaseHelper.KEY_COM_USUARIO, usuarioLogueado)
                    put(DatabaseHelper.KEY_COM_TEXTO, comText)
                    put(DatabaseHelper.KEY_COM_ESTRELLAS, starVal.toInt())
                }
                db.insert(DatabaseHelper.TABLA_COMENTARIOS, null, v)
                edtComentario.text.clear()
                edtEstrellas.text.clear()
                cargarUltimoEvento()
            }
        }

        cargarUltimoEvento()
        return view
    }
}