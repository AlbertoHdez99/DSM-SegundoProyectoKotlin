package com.example.navegacionapp

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val dbHelper = DatabaseHelper(this)
        val edtEmail = findViewById<EditText>(R.id.edtEmail)
        val edtPassword = findViewById<EditText>(R.id.edtPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnRegister = findViewById<Button>(R.id.btnRegister)

        btnLogin.setOnClickListener {
            val email = edtEmail.text.toString().trim()
            val pass = edtPassword.text.toString().trim()

            if (email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Por favor llena todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                val db = dbHelper.readableDatabase
                val cursor = db.rawQuery(
                    "SELECT * FROM ${DatabaseHelper.TABLA_USUARIOS} WHERE ${DatabaseHelper.KEY_USER_EMAIL}=? AND ${DatabaseHelper.KEY_USER_PASS}=?",
                    arrayOf(email, pass)
                )
                if (cursor.moveToFirst()) {
                    val prefs = getSharedPreferences("SesionUsuario", Context.MODE_PRIVATE)
                    prefs.edit().putString("email", email).apply()

                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show()
                }
                cursor.close()
            }
        }

        btnRegister.setOnClickListener {
            val email = edtEmail.text.toString().trim()
            val pass = edtPassword.text.toString().trim()

            if (email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Llena los campos para registrarte", Toast.LENGTH_SHORT).show()
            } else {
                val db = dbHelper.writableDatabase
                val values = ContentValues().apply {
                    put(DatabaseHelper.KEY_USER_EMAIL, email)
                    put(DatabaseHelper.KEY_USER_PASS, pass)
                }
                val resultado = db.insert(DatabaseHelper.TABLA_USUARIOS, null, values)
                if (resultado != -1L) {
                    Toast.makeText(this, "Usuario registrado con éxito", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "El usuario ya existe o hubo un error", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}