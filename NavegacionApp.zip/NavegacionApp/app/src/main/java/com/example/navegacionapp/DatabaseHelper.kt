package com.example.navegacionapp

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "ComunidadEventos.db"
        private const val DATABASE_VERSION = 1

        const val TABLA_USUARIOS = "usuarios"
        const val KEY_USER_ID = "id"
        const val KEY_USER_EMAIL = "email"
        const val KEY_USER_PASS = "password"

        const val TABLA_EVENTOS = "eventos"
        const val KEY_EV_ID = "id"
        const val KEY_EV_TITULO = "titulo"
        const val KEY_EV_DESC = "descripcion"
        const val KEY_EV_FECHA = "fecha"
        const val KEY_EV_HORA = "hora"
        const val KEY_EV_UBICACION = "ubicacion"

        const val TABLA_COMENTARIOS = "comentarios"
        const val KEY_COM_ID = "id"
        const val KEY_COM_EVENTO_ID = "evento_id"
        const val KEY_COM_USUARIO = "usuario"
        const val KEY_COM_TEXTO = "texto"
        const val KEY_COM_ESTRELLAS = "estrellas"

        const val TABLA_HISTORIAL = "historial"
        const val KEY_HIST_ID = "id"
        const val KEY_HIST_USER_EMAIL = "user_email"
        const val KEY_HIST_EVENTO_ID = "evento_id"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val crearUsuarios = ("CREATE TABLE " + TABLA_USUARIOS + "("
                + KEY_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_USER_EMAIL + " TEXT UNIQUE,"
                + KEY_USER_PASS + " TEXT)")

        val crearEventos = ("CREATE TABLE " + TABLA_EVENTOS + "("
                + KEY_EV_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_EV_TITULO + " TEXT,"
                + KEY_EV_DESC + " TEXT,"
                + KEY_EV_FECHA + " TEXT,"
                + KEY_EV_HORA + " TEXT,"
                + KEY_EV_UBICACION + " TEXT)")

        val crearComentarios = ("CREATE TABLE " + TABLA_COMENTARIOS + "("
                + KEY_COM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_COM_EVENTO_ID + " INTEGER,"
                + KEY_COM_USUARIO + " TEXT,"
                + KEY_COM_TEXTO + " TEXT,"
                + KEY_COM_ESTRELLAS + " INTEGER)")

        val crearHistorial = ("CREATE TABLE " + TABLA_HISTORIAL + "("
                + KEY_HIST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_HIST_USER_EMAIL + " TEXT,"
                + KEY_HIST_EVENTO_ID + " INTEGER)")

        db.execSQL(crearUsuarios)
        db.execSQL(crearEventos)
        db.execSQL(crearComentarios)
        db.execSQL(crearHistorial)

        // Datos semilla precargados automáticos para la defensa
        db.execSQL("INSERT INTO $TABLA_EVENTOS ($KEY_EV_TITULO, $KEY_EV_DESC, $KEY_EV_FECHA, $KEY_EV_HORA, $KEY_EV_UBICACION) VALUES ('Torneo de Atletismo UDB', 'Competencia de saltos y velocidad académica.', '2026-06-15', '08:00', 'Polideportivo UDB')")
        db.execSQL("INSERT INTO $TABLA_EVENTOS ($KEY_EV_TITULO, $KEY_EV_DESC, $KEY_EV_FECHA, $KEY_EV_HORA, $KEY_EV_UBICACION) VALUES ('Feria de Software y Robótica', 'Exposición de proyectos de fin de ciclo.', '2026-05-30', '10:00', 'Gimnasio Universitario')")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLA_USUARIOS")
        db.execSQL("DROP TABLE IF EXISTS $TABLA_EVENTOS")
        db.execSQL("DROP TABLE IF EXISTS $TABLA_COMENTARIOS")
        db.execSQL("DROP TABLE IF EXISTS $TABLA_HISTORIAL")
        onCreate(db)
    }
}